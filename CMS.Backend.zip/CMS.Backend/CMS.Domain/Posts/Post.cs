﻿using CMS.Domain.Comments;
using CMS.Domain.Common;
using CMS.Domain.Tags;
using CMS.Domain.Users;
using System.ComponentModel.DataAnnotations.Schema;

namespace CMS.Domain.Posts
{
    public class Post : AuditEntity
    {
        public string Title { get; set; } = default!;
        public string Content { get; set; } = default!;
        public string Summary { get; set; } = default!;
        public int Priority { get; set; } 
        public string? ImageUrl { get; set; } = default!;
        public bool IsDraw { get; set; }
        public DateTime PublishDate { get; set; }
        [ForeignKey("User")]
        public Guid UserId { get; set; }
        public User User { get; set; } = default!;
        public ICollection<Tag> Tags { get; set; } = default!;
        public ICollection<Comment> Comments { get; set; } = default!;
    }
}
