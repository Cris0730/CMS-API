﻿using CMS.Domain.Common;

namespace CMS.Domain.Tags
{
    public class Tag : BaseEntity
    {
        public string Name { get; set; } = default!;
        public DateTime CreationDate { get; set; }

        public Tag()
        {
           CreationDate = DateTime.Now;
        }
       
    }
}
