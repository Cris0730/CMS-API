﻿using CMS.Domain.Comments;
using CMS.Domain.Common;
using CMS.Domain.Posts;

namespace CMS.Domain.Users
{
    public class User : AuditEntity
    {
        public string FirstName { get; set; } = default!;
        public string LastName { get; set; } = default!;

        public ICollection<Post>? Posts { get; set; }
        public ICollection<Comment>? Comments { get; set; }

    }
}
