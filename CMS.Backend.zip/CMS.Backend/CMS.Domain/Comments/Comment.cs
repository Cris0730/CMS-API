﻿using CMS.Domain.Common;
using CMS.Domain.Posts;
using CMS.Domain.Users;
using System.ComponentModel.DataAnnotations.Schema;

namespace CMS.Domain.Comments
{
    public class Comment : AuditEntity
    {
        public string? Content { get; set; }
        [ForeignKey("Post")]
        public Guid PostId { get; set; }
        public Post Post { get; set; } = default!;
        [ForeignKey("User")]
        public Guid UserId { get; set; }
        public User User { get; set; } = default!;
    }
}
