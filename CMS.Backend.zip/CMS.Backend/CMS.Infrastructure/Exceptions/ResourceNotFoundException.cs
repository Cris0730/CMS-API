﻿namespace CMS.Infrastructure.Exceptions
{
    public class ResourceNotFoundException(string message) : Exception(message)
    {
    }
}
