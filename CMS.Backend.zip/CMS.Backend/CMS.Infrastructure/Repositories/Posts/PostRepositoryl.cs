﻿
using CMS.Domain.Posts;
using CMS.Infrastructure.Contexts;
using CMS.Infrastructure.Exceptions;
using CMS.Infrastructure.Repositories.Posts.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Repositories.Posts
{
    public class PostRepository(CmsContext context) : IPostRepository
    {
        public async Task<Post> CreatePostAsync(Post input)
        {
            await context.Posts.AddAsync(input);
            await context.SaveChangesAsync();
            return input;
        }

        public async Task<bool> DeletePostByIdAsync(Guid id)
        {
            var post = await GetPostByIdAsync(id);

            context.Posts.Remove(post);

            return await context.SaveChangesAsync() > 0;
        }

        public async Task<ICollection<Post>> GetAllPostAsync()
        {
            var posts = await context.Posts.ToListAsync();

            return posts;
        }

        public async Task<Post> GetPostByIdAsync(Guid id)
        {
            var post = await context.Posts.FirstOrDefaultAsync(x => x.Id == id) ?? throw new ResourceNotFoundException($"Post con id {id} no fue encontrado");
            return post;
        }

        public async Task<Post> UpdatePostAsync(Post input)
        {
            context.Posts.Update(input);
            await context.SaveChangesAsync();
            return input;
        }
    }
}
