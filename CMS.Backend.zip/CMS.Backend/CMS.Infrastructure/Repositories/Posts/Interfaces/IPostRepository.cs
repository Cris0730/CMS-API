﻿using CMS.Domain.Posts;

namespace CMS.Infrastructure.Repositories.Posts.Interfaces
{

    public interface IPostRepository
    {
        Task<Post> CreatePostAsync(Post input);
        Task<Post> UpdatePostAsync(Post input);
        Task<Post> GetPostByIdAsync(Guid id);
        Task<bool> DeletePostByIdAsync(Guid id);
        Task<ICollection<Post>> GetAllPostAsync();
    }
}
