﻿using CMS.Domain.Tags;

namespace CMS.Infrastructure.Repositories.Tags.Interfaces
{
    public interface ITagRepository
    {
        Task<Tag> CreateTagAsync(Tag input);
        Task<Tag> UpdateTagAsync(Tag input);
        Task<Tag> GetTagByIdAsync(Guid id);
        Task<bool> DeleteTagByIdAsync(Guid id);
        Task<ICollection<Tag>> GetAllAsync();
    }
}
