﻿using CMS.Domain.Tags;
using CMS.Infrastructure.Contexts;
using CMS.Infrastructure.Exceptions;
using CMS.Infrastructure.Repositories.Tags.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Repositories.Tags
{
    public class TagRepository(CmsContext context) : ITagRepository
    {
        public async Task<Tag> CreateTagAsync(Tag input)
        {
            await context.Tags.AddAsync(input);
            await context.SaveChangesAsync();

            return input;
        }

        public async Task<bool> DeleteTagByIdAsync(Guid id)
        {
            var tag = await GetTagByIdAsync(id);
            context.Tags.Remove(tag);
            return await context.SaveChangesAsync() > 0;
        }

        public async Task<ICollection<Tag>> GetAllAsync()
        {
            var posts = await context.Tags.ToListAsync();
            return posts;
        }

        public async Task<Tag> GetTagByIdAsync(Guid id)
        {
            var post = await context.Tags.FirstOrDefaultAsync(x => x.Id == id) ?? throw new ResourceNotFoundException($"Tag con id {id} no fue encontrado");
            return post;
        }

        public async Task<Tag> UpdateTagAsync(Tag input)
        {
            context.Tags.Update(input);
            await context.SaveChangesAsync();

            return input;
        }
    }
}
