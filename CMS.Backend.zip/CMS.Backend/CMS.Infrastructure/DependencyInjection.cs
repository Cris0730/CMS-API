﻿using CMS.Infrastructure.Contexts;
using CMS.Infrastructure.Repositories.Posts;
using CMS.Infrastructure.Repositories.Posts.Interfaces;
using CMS.Infrastructure.Repositories.Tags;
using CMS.Infrastructure.Repositories.Tags.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CMS.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<CmsContext>(options =>
                options.UseSqlServer(
                    configuration.GetConnectionString("DefaultConnection"),
                    b => b.MigrationsAssembly(typeof(CmsContext).Assembly.FullName)));

            services.AddScoped<IPostRepository, PostRepository>();
            services.AddScoped<ITagRepository, TagRepository>();

            return services;
        }
    }
}
