﻿using CMS.Domain.Comments;
using CMS.Domain.Posts;
using CMS.Domain.Tags;
using CMS.Domain.Users;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Contexts
{
    public class CmsContext : DbContext
    {
        public DbSet<Post> Posts { get; set; } = default!;
        public DbSet<Tag> Tags { get; set; } = default!;
        public DbSet<Comment> Commments { get; set; } = default!;
        public DbSet<User> Users { get; set; } = default!;

        public CmsContext(DbContextOptions<CmsContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Post>()
                .HasOne(p => p.User)
                .WithMany(u => u.Posts)
                .HasForeignKey(p => p.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Comment>()
                .HasOne(c => c.User)
                .WithMany(u => u.Comments)
                .HasForeignKey(c => c.UserId)
                .OnDelete(DeleteBehavior.Restrict);
            
        }

    }
}
