using CMS.Application.Posts.Exceptions;
using CMS.Application.Posts.Interfaces;
using CMS.Application.Posts.Models;
using CMS.Infrastructure.Exceptions;
using Microsoft.AspNetCore.Mvc;

namespace CMS.Backend.Controllers.Posts
{
    [ApiController]
    [Route("[controller]")]
    public class PostController(IPostService postService) : ControllerBase
    {

        [HttpGet]
        public async Task<IActionResult> GetPosts()
        {
            try
            {
                var posts = await postService.GetAllPostAsync();
                return Ok(posts);
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPostByIdAsync([FromRoute] Guid id)
        {
            try
            {
                var posts = await postService.GetPostByIdAsync(id);
                return Ok(posts);
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }

        }

        [HttpPost]
        public async Task<IActionResult> CreatePostAsync([FromBody] PostCreateDto input)
        {
            try
            {
                var createdPost = await postService.CreatePostAsync(input);
                return StatusCode(StatusCodes.Status201Created, createdPost);
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    UserPostRequiredException _ => StatusCode(StatusCodes.Status400BadRequest, ex.Message),
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }
            
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePostAsync([FromRoute] Guid id, [FromBody] PostReadDto input)
        {
            try
            {
                var updatedPost = await postService.UpdatePostAsync(input);
                return StatusCode(StatusCodes.Status202Accepted, updatedPost);
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    InvalidOperationException => StatusCode(StatusCodes.Status400BadRequest, ex.Message),
                    ResourceNotFoundException => StatusCode(StatusCodes.Status404NotFound, ex.Message),
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePostAsync([FromRoute] Guid id)
        {
            try
            {
                var result = await postService.DeletePostAsync(id);
                if (result)
                {
                    return StatusCode(StatusCodes.Status202Accepted);
                }
                else
                {
                    return StatusCode(StatusCodes.Status400BadRequest, "Post no pudo ser eliminado");
                }
                
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    ResourceNotFoundException => StatusCode(StatusCodes.Status404NotFound, ex.Message),
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }
        }
    }
}
