using CMS.Application.Tags.Interfaces;
using CMS.Application.Tags.Models;
using CMS.Infrastructure.Exceptions;
using Microsoft.AspNetCore.Mvc;

namespace CMS.Backend.Controllers.Tags
{
    [ApiController]
    [Route("[controller]")]
    public class TagController(ITagService tagService) : ControllerBase
    {

        [HttpGet]
        public async Task<IActionResult> GetTags()
        {
            try
            {
                var tags = await tagService.GetAllTagAsync();
                return Ok(tags);
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTagByIdAsync([FromRoute] Guid id)
        {
            try
            {
                var tags = await tagService.GetTagByIdAsync(id);
                return Ok(tags);
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }

        }

        [HttpPost]
        public async Task<IActionResult> CreateTagAsync([FromBody] TagCreateDto input)
        {
            try
            {
                var createdTag = await tagService.CreateTagAsync(input);
                return StatusCode(StatusCodes.Status201Created, createdTag);
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }
            
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTagAsync([FromRoute] Guid id, [FromBody] TagReadDto input)
        {
            try
            {
                var updatedTag = await tagService.UpdateTagAsync(input);
                return StatusCode(StatusCodes.Status202Accepted, updatedTag);
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    InvalidOperationException => StatusCode(StatusCodes.Status400BadRequest, ex.Message),
                    ResourceNotFoundException => StatusCode(StatusCodes.Status404NotFound, ex.Message),
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTagAsync([FromRoute] Guid id)
        {
            try
            {
                var result = await tagService.DeleteTagAsync(id);
                if (result)
                {
                    return StatusCode(StatusCodes.Status202Accepted);
                }
                else
                {
                    return StatusCode(StatusCodes.Status400BadRequest, "Tag no pudo ser eliminado");
                }
                
            }
            catch (Exception ex)
            {
                return ex switch
                {
                    ResourceNotFoundException => StatusCode(StatusCodes.Status404NotFound, ex.Message),
                    _ => StatusCode(StatusCodes.Status500InternalServerError, ex.Message)
                };
            }
        }
    }
}
