﻿namespace CMS.Application.Tags.Models
{
    public class TagCreateDto
    {
        public string Name { get; set; } = default!;
        public DateTime CreationDate { get; set; }
    }
}
