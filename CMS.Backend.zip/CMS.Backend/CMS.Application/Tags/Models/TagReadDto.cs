﻿using CMS.Application.Common;

namespace CMS.Application.Tags.Models
{
    public class TagReadDto : BaseDto
    {
        public string Name { get; set; } = default!;
        public DateTime CreationDate { get; set; }
    }
}
