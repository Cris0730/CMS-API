﻿using CMS.Application.Tags.Interfaces;
using CMS.Application.Tags.Models;
using CMS.Domain.Tags;
using CMS.Infrastructure.Repositories.Tags.Interfaces;

namespace CMS.Application.Tags
{
    public class TagService(ITagRepository tagRepository) : ITagService
    {

        public async Task<TagReadDto> CreateTagAsync(TagCreateDto input)
        {

            var newTag = new Tag
            {
                CreationDate = DateTime.Now,
                Name = input.Name,
                
            };

            newTag = await tagRepository.CreateTagAsync(newTag);

            return new TagReadDto
            {
                Id = newTag.Id,
                Name = newTag.Name,
                CreationDate = newTag.CreationDate,
            };
        }

        public async Task<bool> DeleteTagAsync(Guid id)
        {
            var result = await tagRepository.DeleteTagByIdAsync(id);

            return result;
        }

        public async Task<ICollection<TagReadDto>> GetAllTagAsync()
        {
            var tags = await tagRepository.GetAllAsync();

            return tags.Select(x => new TagReadDto
            {
                Id = x.Id,
                Name = x.Name,
                CreationDate = x.CreationDate,
            }).ToList();
        }

        public async Task<TagReadDto> GetTagByIdAsync(Guid id)
        {
            var tag = await tagRepository.GetTagByIdAsync(id);

            return new TagReadDto
            {
                Id = tag.Id,
                CreationDate = tag.CreationDate,
                Name = tag.Name,
            };
        }

        public async Task<TagReadDto> UpdateTagAsync(TagReadDto input)
        {
            var tagToUpdate = new Tag
            {
                Id = input.Id,
                CreationDate = input.CreationDate,
                Name = input.Name,
            };

            _ = await tagRepository.UpdateTagAsync(tagToUpdate);

            return input;
        }
    }
}
