﻿using CMS.Application.Tags.Models;

namespace CMS.Application.Tags.Interfaces
{
    public interface ITagService
    {
        Task<TagReadDto> CreateTagAsync(TagCreateDto input);
        Task<TagReadDto> UpdateTagAsync(TagReadDto input);
        Task<bool> DeleteTagAsync(Guid id);
        Task<TagReadDto> GetTagByIdAsync(Guid id);
        Task<ICollection<TagReadDto>> GetAllTagAsync();
    }
}
