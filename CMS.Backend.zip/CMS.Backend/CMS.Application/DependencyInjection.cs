﻿using CMS.Application.Posts;
using CMS.Application.Posts.Interfaces;
using CMS.Application.Tags;
using CMS.Application.Tags.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace CMS.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {

            services.AddScoped<IPostService, PostService>();
            services.AddScoped<ITagService, TagService>();

            return services;
        }
    }
}
