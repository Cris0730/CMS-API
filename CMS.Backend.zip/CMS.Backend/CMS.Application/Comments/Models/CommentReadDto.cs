﻿namespace CMS.Application.Comments.Models
{
    public class CommentReadDto
    {
        public Guid Id { get; set; }
        public string Content { get; set; } = default!;
        public Guid PostId { get; set; }
        public Guid UserId { get; set; }
    }
}
