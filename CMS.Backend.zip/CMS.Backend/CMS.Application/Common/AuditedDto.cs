﻿
namespace CMS.Application.Common
{
    public class AuditedDto : BaseDto
    {
    }
}
