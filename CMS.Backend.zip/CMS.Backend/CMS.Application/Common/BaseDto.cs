﻿namespace CMS.Application.Common
{
    public class BaseDto
    {
        public Guid Id { get; set; }
    }
}
