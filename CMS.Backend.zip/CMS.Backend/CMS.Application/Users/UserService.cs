﻿using CMS.Application.Users.Interfaces;
using CMS.Application.Users.Models;

namespace CMS.Application.Users
{
    public class UserService : IUserService
    {
        public Task<UserReadDto> GetUserById(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
