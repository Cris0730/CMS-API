﻿using CMS.Application.Users.Models;

namespace CMS.Application.Users.Interfaces
{
    public interface IUserService
    {
        Task<UserReadDto> GetUserById(Guid id);
    }
}
