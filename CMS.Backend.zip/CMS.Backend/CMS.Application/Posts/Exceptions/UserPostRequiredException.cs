﻿namespace CMS.Application.Posts.Exceptions
{
    public class UserPostRequiredException(string message) : Exception(message)
    {
    }
}
