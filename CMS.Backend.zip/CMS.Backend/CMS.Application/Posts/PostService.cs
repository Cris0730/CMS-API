﻿using CMS.Application.Posts.Exceptions;
using CMS.Application.Posts.Interfaces;
using CMS.Application.Posts.Models;
using CMS.Domain.Posts;
using CMS.Infrastructure.Repositories.Posts.Interfaces;

namespace CMS.Application.Posts
{
    public class PostService(IPostRepository postRepository) : IPostService
    {

        public async Task<PostReadDto> CreatePostAsync(PostCreateDto input)
        {

            if (input.UserId == Guid.Empty)
            {
                throw new UserPostRequiredException($"UserId is required to create new Post");
            }

            var newPost = new Post
            {
                Title = input.Title,
                ImageUrl = input.ImageUrl,
                Content = input.Content,
                CreatedBy = input.UserId.ToString(),
                IsDraw = input.IsDraw,
                Summary = input.Summary,
                Priority = input.Priority,
                UserId = input.UserId,
            };

            newPost = await postRepository.CreatePostAsync(newPost);

            return new PostReadDto
            {
                Id = newPost.Id,
                Title = newPost.Title,
                ImageUrl = newPost.ImageUrl,
                Content = newPost.Content,
                IsDraw = newPost.IsDraw,
                Summary = newPost.Summary,
                Priority = newPost.Priority,
                UserId = newPost.UserId,
            };
        }

        public async Task<bool> DeletePostAsync(Guid id)
        {
            var result = await postRepository.DeletePostByIdAsync(id);

            return result;
        }

        public async Task<ICollection<PostReadDto>> GetAllPostAsync()
        {
            var posts = await postRepository.GetAllPostAsync();

            return posts.Select(x => new PostReadDto
            {
                Id = x.Id,
                Title = x.Title,
                ImageUrl = x.ImageUrl,
                Content = x.Content,
                IsDraw = x.IsDraw,
                Summary = x.Summary,
                Priority = x.Priority,
                UserId = x.UserId,
            }).ToList();
        }

        public async Task<PostReadDto> GetPostByIdAsync(Guid id)
        {
            var post = await postRepository.GetPostByIdAsync(id);

            return new PostReadDto
            {
                Id = post.Id,
                Title = post.Title,
                ImageUrl = post.ImageUrl,
                Content = post.Content,
                IsDraw = post.IsDraw,
                Summary = post.Summary,
                Priority = post.Priority,
                UserId = post.UserId,
            };
        }

        public async Task<PostReadDto> UpdatePostAsync(PostReadDto input)
        {
            var postToUpdate = new Post
            {
                Id = input.Id,
                Title = input.Title,
                ImageUrl = input.ImageUrl,
                Content = input.Content,
                IsDraw = input.IsDraw,
                Summary = input.Summary,
                Priority = input.Priority,
                UserId = input.UserId,
            };

            _ = await postRepository.UpdatePostAsync(postToUpdate);

            return input;
        }
    }
}
