﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Application.Posts.Models
{
    public class PostCreateDto
    {
        public string Title { get; set; } = default!;
        public string Content { get; set; } = default!;
        public string Summary { get; set; } = default!;
        public int Priority { get; set; }
        public string? ImageUrl { get; set; } = default!;
        public bool IsDraw { get; set; }
        public DateTime PublishDate { get; set; }
        public Guid UserId { get; set; }
    }
}
