﻿using CMS.Application.Common;

namespace CMS.Application.Posts.Models
{
    public class PostReadDto : BaseDto
    {
        public string Title { get; set; } = default!;
        public string Content { get; set; } = default!;
        public string Summary { get; set; } = default!;
        public int Priority { get; set; }
        public string? ImageUrl { get; set; } = default!;
        public bool IsDraw { get; set; }
        public DateTime PublishDate { get; set; }
        public Guid UserId { get; set; }
    }
}
