﻿using CMS.Application.Posts.Models;

namespace CMS.Application.Posts.Interfaces
{
    public interface IPostService
    {
        Task<PostReadDto> CreatePostAsync(PostCreateDto input);
        Task<PostReadDto> UpdatePostAsync(PostReadDto input);
        Task<bool> DeletePostAsync(Guid id);
        Task<PostReadDto> GetPostByIdAsync(Guid id);
        Task<ICollection<PostReadDto>> GetAllPostAsync();
    }
}
